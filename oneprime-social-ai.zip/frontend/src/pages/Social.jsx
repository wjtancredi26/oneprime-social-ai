export default function Social() {
  return (
    <section className="panel">
      <h2>📱 Redes Sociais</h2>
      <p>Em breve você poderá conectar Instagram, Facebook, WhatsApp e outras redes.</p>
    </section>
  );
}