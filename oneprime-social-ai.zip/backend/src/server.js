import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "path";

import authRoutes from "./routes/authRoutes.js";
import publishRoutes from "./routes/publishRoutes.js";
import mediaRoutes from "./routes/mediaRoutes.js";
import postRoutes from "./routes/postRoutes.js";
import companyRoutes from "./routes/companyRoutes.js";
import aiChatRoutes from "./routes/aiChatRoutes.js";
import metaAuthRoutes from "./routes/metaAuthRoutes.js";

dotenv.config();

const app = express();

app.use(cors());

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

app.use("/uploads", express.static(path.resolve("uploads")));

app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    service: "oneprime-backend",
  });
});

app.use("/auth", authRoutes);
app.use("/posts", postRoutes);
app.use("/publish", publishRoutes);
app.use("/media", mediaRoutes);
app.use("/companies", companyRoutes);
app.use("/ai", aiChatRoutes);
app.use("/meta", metaAuthRoutes);

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(`Backend rodando na porta ${PORT}`);
});