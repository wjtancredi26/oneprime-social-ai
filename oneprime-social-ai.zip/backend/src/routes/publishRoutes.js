import express from "express";
import { PrismaClient } from "@prisma/client";
import { publishFacebookPost } from "../services/metaService.js";

const router = express.Router();
const prisma = new PrismaClient();

router.post("/facebook", async (req, res) => {
  try {
    const { message, imageUrl } = req.body;

    if (!message) {
      return res.status(400).json({
        success: false,
        error: "Mensagem obrigatória.",
      });
    }

    const result = await publishFacebookPost({ message, imageUrl });

    res.json({
      success: true,
      result,
    });
  } catch (error) {
    console.error("ERRO AO PUBLICAR NO FACEBOOK:", error);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

router.post("/facebook/post/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const post = await prisma.scheduledPost.findUnique({
      where: { id: Number(id) },
    });

    if (!post) {
      return res.status(404).json({
        success: false,
        error: "Postagem não encontrada.",
      });
    }

    const message = `${post.caption}

${post.hashtags || ""}

${post.cta || ""}`;

    const result = await publishFacebookPost({
      message,
      imageUrl: post.imageUrl,
    });

    const updatedPost = await prisma.scheduledPost.update({
      where: { id: Number(id) },
      data: {
        status: "PUBLICADO",
      },
    });

    res.json({
      success: true,
      result,
      post: updatedPost,
    });
  } catch (error) {
    console.error("ERRO AO PUBLICAR POST:", error);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

export default router;