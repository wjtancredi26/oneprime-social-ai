import express from "express";

const router = express.Router();

router.get("/login", (req, res) => {
  const params = new URLSearchParams({
    client_id: process.env.META_APP_ID,
    redirect_uri: process.env.META_REDIRECT_URI,
    scope: [
      "pages_show_list",
      "pages_read_engagement",
      "pages_manage_posts",
      "pages_manage_metadata",
      "business_management",
      "instagram_basic",
      "instagram_content_publish",
    ].join(","),
    response_type: "code",
    auth_type: "rerequest",
  });

  res.redirect(`https://www.facebook.com/v25.0/dialog/oauth?${params}`);
});

router.get("/callback", async (req, res) => {
  try {
    const { code } = req.query;

    if (!code) {
      return res.json({
        success: false,
        error: "Código de autorização não recebido.",
      });
    }

    const tokenUrl = new URL("https://graph.facebook.com/v25.0/oauth/access_token");

    tokenUrl.searchParams.set("client_id", process.env.META_APP_ID);
    tokenUrl.searchParams.set("client_secret", process.env.META_APP_SECRET);
    tokenUrl.searchParams.set("redirect_uri", process.env.META_REDIRECT_URI);
    tokenUrl.searchParams.set("code", code);

    const tokenResponse = await fetch(tokenUrl);
    const tokenData = await tokenResponse.json();

    if (!tokenData.access_token) {
      return res.json({
        success: false,
        step: "token_exchange",
        error: tokenData,
      });
    }

    const pagesResponse = await fetch(
      `https://graph.facebook.com/v25.0/me/accounts?fields=id,name,access_token,tasks&access_token=${tokenData.access_token}`
    );

    const pagesData = await pagesResponse.json();

    return res.json({
      success: true,
      message: "Conexão Meta realizada com sucesso.",
      userTokenStart: tokenData.access_token.substring(0, 25),
      pages: pagesData.data || [],
      raw: pagesData,
    });
  } catch (error) {
    console.error("ERRO META CALLBACK:", error);

    return res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

export default router;