import express from "express";
import multer from "multer";
import path from "path";
import {
  ensureUploadDir,
  generateMetaImageFileName,
  buildPublicImageUrl,
} from "../services/mediaService.js";

const router = express.Router();

ensureUploadDir();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/meta");
  },
  filename: (req, file, cb) => {
    cb(null, generateMetaImageFileName(file.originalname));
  },
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = ["image/jpeg", "image/png", "image/webp"];

  if (!allowedTypes.includes(file.mimetype)) {
    return cb(new Error("Formato inválido. Envie JPG, PNG ou WEBP."));
  }

  cb(null, true);
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 8 * 1024 * 1024,
  },
});

router.post("/upload-image", upload.single("image"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Nenhuma imagem enviada.",
      });
    }

    const imageUrl = buildPublicImageUrl(req.file.filename);

    return res.json({
      success: true,
      message: "Imagem enviada com sucesso.",
      imageUrl,
      filename: req.file.filename,
      mimetype: req.file.mimetype,
      size: req.file.size,
    });
  } catch (error) {
    console.error("ERRO AO FAZER UPLOAD DA IMAGEM:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro ao fazer upload da imagem.",
    });
  }
});

export default router;