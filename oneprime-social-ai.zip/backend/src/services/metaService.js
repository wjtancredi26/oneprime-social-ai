function validatePublicImageUrl(imageUrl) {
  if (!imageUrl || imageUrl.trim() === "") {
    return false;
  }

  try {
    const url = new URL(imageUrl);

    if (!["http:", "https:"].includes(url.protocol)) {
      throw new Error("A URL da imagem precisa começar com http:// ou https://");
    }

    return true;
  } catch {
    throw new Error(
      `imageUrl inválida para a Meta: ${imageUrl}. A imagem precisa estar em uma URL pública válida.`
    );
  }
}

export async function publishFacebookPost({ message, imageUrl }) {
  const pageId = process.env.META_PAGE_ID;
  const accessToken = process.env.META_PAGE_ACCESS_TOKEN;
  const graphVersion = process.env.META_GRAPH_VERSION || "v25.0";

  if (!pageId || !accessToken) {
    throw new Error("META_PAGE_ID ou META_PAGE_ACCESS_TOKEN não configurado.");
  }

  if (!message || message.trim() === "") {
    throw new Error("Mensagem obrigatória para publicar no Facebook.");
  }

  const hasImage = validatePublicImageUrl(imageUrl);

  const endpoint = hasImage
    ? `https://graph.facebook.com/${graphVersion}/${pageId}/photos`
    : `https://graph.facebook.com/${graphVersion}/${pageId}/feed`;

  const body = hasImage
    ? {
        url: imageUrl,
        caption: message,
        access_token: accessToken,
      }
    : {
        message,
        access_token: accessToken,
      };

  console.log("PUBLICANDO NO FACEBOOK:");
  console.log({
    endpoint,
    hasImage,
    imageUrl: hasImage ? imageUrl : null,
  });

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();

  console.log("RESPOSTA META:", JSON.stringify(data, null, 2));

  if (!response.ok) {
    throw new Error(data.error?.message || "Erro ao publicar no Facebook.");
  }

  return data;
}