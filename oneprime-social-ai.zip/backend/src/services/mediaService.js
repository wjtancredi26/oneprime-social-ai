import fs from "fs";
import path from "path";
import { v4 as uuidv4 } from "uuid";

const UPLOAD_DIR = path.resolve("uploads/meta");

export function ensureUploadDir() {
  if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  }
}

export function generateMetaImageFileName(originalName) {
  const ext = path.extname(originalName || ".jpg").toLowerCase();
  return `${uuidv4()}${ext}`;
}

export function buildPublicImageUrl(filename) {
  const baseUrl = process.env.PUBLIC_BASE_URL;

  if (!baseUrl) {
    throw new Error("PUBLIC_BASE_URL não configurado no .env");
  }

  return `${baseUrl}/uploads/meta/${filename}`;
}