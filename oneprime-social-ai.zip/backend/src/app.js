import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";
import { PrismaClient } from "@prisma/client";

import authRoutes from "./routes/authRoutes.js";
import aiChatRoutes from "./routes/aiChatRoutes.js";
import companyRoutes from "./routes/companyRoutes.js";
import publishRoutes from "./routes/publishRoutes.js";
import metaAuthRoutes from "./routes/metaAuthRoutes.js";

dotenv.config({ override: true });

const app = express();
const prisma = new PrismaClient();

app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

app.get("/health", (req, res) => {
  res.json({ status: "ok", service: "oneprime-backend" });
});

app.use("/auth", authRoutes);
app.use("/api/ai", aiChatRoutes);
app.use("/api/companies", companyRoutes);
app.use("/api/publish", publishRoutes);
app.use("/api/meta", metaAuthRoutes);

async function getDefaultUser() {
  let user = await prisma.user.findFirst();

  if (!user) {
    user = await prisma.user.create({
      data: {
        name: "Wilian",
        email: "wilian@oneprimeseg.com.br",
        password: "123456",
        role: "ADMIN",
      },
    });
  }

  return user;
}

app.post("/api/ai/generate", async (req, res) => {
  try {
    const { prompt } = req.body;

    if (!prompt) {
      return res.status(400).json({
        success: false,
        error: "Prompt é obrigatório.",
      });
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4.1-mini",
      messages: [
        {
          role: "system",
          content:
            "Você é um especialista em marketing digital para corretoras de seguros. Gere conteúdos profissionais em português do Brasil.",
        },
        {
          role: "user",
          content: `
Crie um conteúdo para redes sociais baseado neste pedido:

${prompt}

Responda EXATAMENTE neste formato:

Legenda:
Hashtags:
Ideia de imagem:
Melhor horário:
CTA:
`,
        },
      ],
    });

    res.json({
      success: true,
      content: response.choices[0].message.content,
    });
  } catch (error) {
    console.error("ERRO CHATGPT:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/ai/image", async (req, res) => {
  try {
    const { prompt, style } = req.body;

    if (!prompt) {
      return res.status(400).json({
        success: false,
        error: "Prompt da imagem é obrigatório.",
      });
    }

    const imagePrompt = `
Crie uma propaganda extremamente profissional.

Tema:
${prompt}

Estilo:
${style || "Publicidade premium"}

Imagem ultra realista.
Alta qualidade.
Publicidade premium.
Sem logotipos de marcas famosas.
Sem textos pequenos.
Foco em marketing digital para seguros.
`;

    const image = await openai.images.generate({
      model: "gpt-image-1",
      prompt: imagePrompt,
      size: "1024x1024",
    });

    const imageBase64 = image?.data?.[0]?.b64_json;
    const imageUrlFromApi = image?.data?.[0]?.url;

    if (imageBase64) {
      return res.json({
        success: true,
        imageUrl: `data:image/png;base64,${imageBase64}`,
      });
    }

    if (imageUrlFromApi) {
      return res.json({
        success: true,
        imageUrl: imageUrlFromApi,
      });
    }

    return res.status(500).json({
      success: false,
      error: "A OpenAI respondeu, mas não retornou imagem.",
    });
  } catch (error) {
    console.error("ERRO AO GERAR IMAGEM:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/posts", async (req, res) => {
  try {
    const {
      prompt,
      caption,
      hashtags,
      imageIdea,
      cta,
      imageUrl,
      network,
      scheduledAt,
      companyId,
    } = req.body;

    if (!prompt || !caption || !network || !scheduledAt) {
      return res.status(400).json({
        success: false,
        error: "Dados obrigatórios ausentes.",
      });
    }

    const user = await getDefaultUser();

    const post = await prisma.scheduledPost.create({
      data: {
        prompt,
        caption,
        hashtags: hashtags || "",
        imageIdea: imageIdea || "",
        cta: cta || "",
        imageUrl: imageUrl || null,
        network,
        scheduledAt: new Date(scheduledAt),
        status: "AGENDADO",
        userId: user.id,
        companyId: companyId ? Number(companyId) : user.companyId || null,
      },
    });

    res.json({ success: true, post });
  } catch (error) {
    console.error("ERRO AO SALVAR POST:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get("/api/posts", async (req, res) => {
  try {
    const posts = await prisma.scheduledPost.findMany({
      orderBy: { scheduledAt: "asc" },
      include: { company: true },
    });

    res.json({ success: true, posts });
  } catch (error) {
    console.error("ERRO AO LISTAR POSTS:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put("/api/posts/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const {
      caption,
      hashtags,
      imageIdea,
      cta,
      imageUrl,
      network,
      scheduledAt,
      status,
      companyId,
    } = req.body;

    const post = await prisma.scheduledPost.update({
      where: { id: Number(id) },
      data: {
        caption,
        hashtags: hashtags || "",
        imageIdea: imageIdea || "",
        cta: cta || "",
        imageUrl: imageUrl || null,
        network,
        scheduledAt: new Date(scheduledAt),
        status: status || "AGENDADO",
        companyId: companyId ? Number(companyId) : null,
      },
    });

    res.json({ success: true, post });
  } catch (error) {
    console.error("ERRO AO EDITAR POST:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete("/api/posts/:id", async (req, res) => {
  try {
    const { id } = req.params;

    await prisma.scheduledPost.delete({
      where: { id: Number(id) },
    });

    res.json({
      success: true,
      message: "Postagem excluída com sucesso.",
    });
  } catch (error) {
    console.error("ERRO AO EXCLUIR POST:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

export default app;