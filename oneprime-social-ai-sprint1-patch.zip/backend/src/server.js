import dotenv from "dotenv";
import app from "./app.js";

dotenv.config({ override: true });

const PORT = process.env.PORT || 3001;

app.listen(PORT, () => {
  console.log(`Backend rodando na porta ${PORT}`);
});
