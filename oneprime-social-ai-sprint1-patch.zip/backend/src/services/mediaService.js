import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { v4 as uuidv4 } from "uuid";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const BACKEND_ROOT = path.resolve(__dirname, "../..");
const UPLOAD_DIR = path.join(BACKEND_ROOT, "uploads", "meta");

export function ensureUploadDir() {
  if (!fs.existsSync(UPLOAD_DIR)) {
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
  }
}

export function generateMetaImageFileName(originalName = "image.png") {
  const ext = path.extname(originalName).toLowerCase() || ".png";
  return `${uuidv4()}${ext}`;
}

export function buildPublicImageUrl(filename) {
  const baseUrl = process.env.PUBLIC_BASE_URL;

  if (!baseUrl) {
    throw new Error("PUBLIC_BASE_URL não configurado no .env");
  }

  return `${baseUrl.replace(/\/$/, "")}/uploads/meta/${filename}`;
}

export function saveImageBuffer(buffer, originalName = "image.png") {
  ensureUploadDir();

  const filename = generateMetaImageFileName(originalName);
  const filePath = path.join(UPLOAD_DIR, filename);

  fs.writeFileSync(filePath, buffer);

  return {
    filename,
    filePath,
    imageUrl: buildPublicImageUrl(filename),
  };
}

export function saveBase64Image(base64Image, originalName = "oneprime-image.png") {
  if (!base64Image) {
    throw new Error("Imagem base64 não informada.");
  }

  const cleanBase64 = base64Image.includes(",")
    ? base64Image.split(",").pop()
    : base64Image;

  const buffer = Buffer.from(cleanBase64, "base64");

  return saveImageBuffer(buffer, originalName);
}

export function getUploadRoot() {
  return path.join(BACKEND_ROOT, "uploads");
}
