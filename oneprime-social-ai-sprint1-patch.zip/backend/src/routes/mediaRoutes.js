import express from "express";
import multer from "multer";
import {
  ensureUploadDir,
  saveImageBuffer,
  saveBase64Image,
} from "../services/mediaService.js";

const router = express.Router();

ensureUploadDir();

const storage = multer.memoryStorage();

const fileFilter = (req, file, cb) => {
  const allowedTypes = ["image/jpeg", "image/png", "image/webp"];

  if (!allowedTypes.includes(file.mimetype)) {
    return cb(new Error("Formato inválido. Envie JPG, PNG ou WEBP."));
  }

  cb(null, true);
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 8 * 1024 * 1024,
  },
});

router.post("/upload-image", upload.single("image"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "Nenhuma imagem enviada.",
      });
    }

    const savedImage = saveImageBuffer(req.file.buffer, req.file.originalname);

    return res.json({
      success: true,
      message: "Imagem enviada com sucesso.",
      imageUrl: savedImage.imageUrl,
      filename: savedImage.filename,
      mimetype: req.file.mimetype,
      size: req.file.size,
    });
  } catch (error) {
    console.error("ERRO AO FAZER UPLOAD DA IMAGEM:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro ao fazer upload da imagem.",
    });
  }
});

router.post("/save-base64", async (req, res) => {
  try {
    const { imageBase64, filename } = req.body;

    if (!imageBase64) {
      return res.status(400).json({
        success: false,
        message: "imageBase64 é obrigatório.",
      });
    }

    const savedImage = saveBase64Image(imageBase64, filename || "oneprime-image.png");

    return res.json({
      success: true,
      message: "Imagem salva com sucesso.",
      imageUrl: savedImage.imageUrl,
      filename: savedImage.filename,
    });
  } catch (error) {
    console.error("ERRO AO SALVAR BASE64:", error);

    return res.status(500).json({
      success: false,
      message: error.message || "Erro ao salvar imagem.",
    });
  }
});

export default router;
